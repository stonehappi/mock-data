<?php

use Slim\App;
use Slim\Http\Request;
use Slim\Http\Response;

return function (App $app) {
    $container = $app->getContainer();

    $app->get('/',function(Request $request,Response $response,array $args)use($container){
        // echo "dddd";
    });
  
    $app->group('/api',function()use($app){
        $container = $app->getContainer();

        $app->get('/data',function(Request $request,Response $response,array $args)use($container){
            $sql="SELECT * FROM user";
            $stmt=$this->db->prepare($sql);
            $stmt->execute();
            $users=$stmt->fetchAll();
            return $this->response->withJson($users);
        });      
    
    });

 
    //--------------------------------------------------------------------------------

    $app->group('/al',function()use($app){
        $container = $app->getContainer();    
        
        // $app->post('/bus/{id}',function(Request $request,Response $response,array $args)use($container){
        //     $body = $this->request->getParsedBody(); 
        //     $sql = "INSERT INTO grade (id, reviews, suggestion, status, Imgproblem, booking_id) 
        //     VALUES (:id,:reviews,:suggestion,:status,:Imgproblem,:booking_id) "; /* SQL**** */
        //     $sts = $this->db->prepare($sql);
        //     $sts->execute();            
        //     $user = $sts->fetchAll();

        //    return $this->response->withJson($user); });

        // -------------------------จังหวัด-----อำเภอ-----ตำบล-------------------------------------------------------------
        $app->get('/povi',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM provinces ";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $business = $sts->fetchAll(); 
            return $this->response->withJson($business);  });
         $app->get('/povi/{id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM provinces WHERE code='$args[id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $business = $sts->fetchAll(); 
            return $this->response->withJson($business);  });

        $app->get('/dsti/{province_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM districts WHERE province_id='$args[province_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $business = $sts->fetchAll(); 
            return $this->response->withJson($business);  });

        $app->get('/sudsti/{district_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM subdistricts WHERE district_id='$args[district_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $business = $sts->fetchAll(); 
            return $this->response->withJson($business);  });


        //------ดึงเลขไปรสณี--ตามเลข--ตำบล-----
        $app->get('/zipxode/{id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT subdistricts.zip_code FROM subdistricts
            WHERE subdistricts.id = '$args[id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $business = $sts->fetchAll(); 
            return $this->response->withJson($business);  });


         // ----------------------จบ---จังหวัด-----อำเภอ-----ตำบล-------------------------------------------------------------
         //-----------------------------ข้อมูล---ประเภท----ข้อมูลย่อย---------------------------------------
         $app->get('/tyrsb',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM typeservice ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();
            while ($a = $sts->fetch(PDO::FETCH_ASSOC)) {
                $typeservice1[ 'id' ] = $a['id'] ; 
                $typeservice1[ 'name_tysbv' ] = $a['name_tysbv'] ;
                // $typeservice[ 'name' ] = Array(); 
                $sql = "SELECT * FROM subservice WHERE typeservice_id='$a[id]'";
                $sts2 = $this->db->prepare($sql);
                $sts2->execute();                
                $typeservice1[ 'name' ] = $sts2->fetchAll();
               
                /* SQL**** ผ่าน*/
                $typeservice[] = $typeservice1;
            } 
            //vvvvvvvยังแก่ไม่ได้----ทำตรงอื่นก่อน---
            // SELECT tags.business_id, tags.service_id, subservice.name FROM business 
            // INNER JOIN tags ON business.id = tags.business_id
            // INNER JOIN subservice ON tags.service_id = subservice.id
            
           return $this->response->withJson($typeservice);  });
           $app->get('/busser',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT subservice.id, subservice.name FROM tags WHERE business_id='43'";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();
            while ($a = $sts->fetch(PDO::FETCH_ASSOC)) {
                // $sql = "SELECT * FROM subservice INNER JOIN typeservice ON subservice.typeservice_id = typeservice.id ";
                $typeservice1[ 'typeservice_id' ] = $a['typeservice_id'] ; 
                $typeservice1[ 'service_id' ] = $a['service_id'] ;                                   
                    $typeservice[ 'name' ] = Array(); 
                        $sql = "SELECT * FROM typeservice WHERE id = '$a[typeservice_id]' ";
                        $sts2 = $this->db->prepare($sql);
                        $sts2->execute();                
                    $typeservice2[ 'name' ] = $sts2->fetchAll();
               
                // /* SQL**** ผ่าน*/
                $typeservice[] = $typeservice1;
            } 
            // $typeservice = $sts->fetchAll(); 
           return $this->response->withJson($typeservice);  });

        //    $app->get('/typosb',function(Request $request,Response $response,array $args)use($container) {
        //     // $body = $this->request->getParsedBody(); 
        //     $sql = "SELECT * FROM typeplaceother ";   /* SQL**** ผ่าน*/
        //     $sts = $this->db->prepare($sql);
        //     $sts->execute();
        //     while ($a = $sts->fetch(PDO::FETCH_ASSOC)) {
        //         $typeplaceother[][ 'id' ] = $a['id'] ; 
        //         $typeplaceother[][ 'name_typo' ] = $a['name_typo'] ;
        //         // $typeservice[ 'name' ] = Array(); 
        //         $sql = "SELECT * FROM placeother WHERE typeplaceother_id='$a[id]'";
        //         $sts2 = $this->db->prepare($sql);
        //         $sts2->execute();                
        //         $typeplaceother[][ 'name' ] = $sts2->fetchAll();
               
        //         /* SQL**** ผ่าน*/
        //     }             
        //     // $typeservice = $sts->fetchAll();

        //    return $this->response->withJson($typeplaceother);  });

        //    // SELECT * FROM  WHERE


          //-------------------------จบ----ข้อมูล---ประเภท----ข้อมูลย่อย---------------------------------------
         //------------------------ค้นหาข้อมุล---ที่พัก---ที่เที่ยว---------------------------------------
         $app->get('/searchst/{districts_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody();
            $sql = "SELECT business.name0, business.detail, image.name as img
            FROM business
            INNER JOIN image ON business.id=image.business_id
            WHERE districts_id='$args[districts_id]'";
            
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $search = $sts->fetchAll();       
            return $this->response->withJson($search); 
         });


         $app->get('/searchtv',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody();
            $sql = "SELECT * FROM servicetime, business
                        ";

            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $search = $sts->fetchAll();       
            return $this->response->withJson($search); 
         });        
         // WHERE servicetime.amountperple='$args[inamountpeople]' AND statu='[0]' RO business.pricel='$args[inamountpeople]' AND business.priceh='$args[inamountpeople]'
         // 	
        //  array $args = ค่าชนิด ช่องข้อมูล มีชื่อว่า args
        //    $app->get('/{intyperoom_id}.{inamountpeople}.{inprice}',function(Request $request,Response $response,array $args)use($container) {
        //     $body = $this->request->getParsedBody();
        //     $sql = "select * from room
        //     where typeroom_id='$args[intyperoom_id]' AND amountpeople='$args[inamountpeople]' AND price='$args[inprice]' AND statu='$args[1]'  ";
        //        $sts = $this->db->prepare($sql);
        //     $sts->execute();            
        //     $user = $sts->fetchAll();       
        //     return $this->response->withJson($user); 
        //  });

        //  SQL    select = ข้อมุลในตาราง (ฟิวร์)   from = ชื่อตาราง (table)    where = ** ข้อมูลที่รับมา + เงื่อนไข

        // SELECT Orders.OrderID, Customers.CustomerName, Orders.OrderDate
        // FROM Orders
        // INNER JOIN Customers
        // ON Orders.CustomerID=Customers.CustomerID;

        // SELECT ชื่อตาราง.ชื่อฟิวร์, ชื่อตารางอื่นๆ.ชื่อฟิวจากตารางอื่นๆ, Orders.OrderDate
        // FROM ชื่อตาราง
        // INNER JOIN ชื่อตารางอื่นๆ
        // ON ชื่อตาราง.ชื่อฟิวร์=ชื่อตารางอื่นๆ.ชื่อฟิวจากตารางอื่นๆ;
        // . คือ หลังจานั้นให้ไปที่ , คือ จำงานก่อนหน้าแล้วให้งานต่อไปได้  = คือ สิ่งหนึ่ง กับ สิงหนึ่ง เหมือนกัน
        // อ่านเป็นไทยได้ว่า
        // เลือก ตาราง จากนั้นไปดูที่ ชื่อฟิวร์ ทำงานต่อไป ชื่อตารางอื่นๆ จากนั้นไปดูที่ ชื่อฟิวจากตารางอื่นๆ
        // จาก ตาราง
        // ภายใน ที่มีรวมกันกับ ชื่อตารางอื่นๆ
        // ใน ตาราง จากนั้นไปดูที่ ชื่อฟิวร์ เหมือนกับ ชื่อตารางอื่นๆ จากนั้นไปดูที่ ชื่อฟิวจากตารางอื่นๆ

        

     
        
          // -------------------------เรียกข้อมูล---ตาม--ID------------------------------------------------------------
      


        //       $app->get('/todo/{tyse}.{sbse}',function(Request $request,Response $response,array $args)use($container) {
        //     // $body = $this->request->getParsedBody(); 
        //     // var_dump($args);
        //     $sql = "SELECT * FROM typeservice, subservice WHERE id='$args[tyse]' AND typeservice_id='$args[sbse]'    ";/* SQL**** ผ่าน*/
        //     $sts = $this->db->prepare($sql);
        //     $sts->execute();            
        //     $user = $sts->fetchAll();
        //     // rowCount
        //     return $this->response->withJson($user); 
        //  });

        //  $app->get('/ty_sbse',function(Request $request,Response $response,array $args)use($container) {
        //     // $body = $this->request->getParsedBody(); 
        //     // var_dump($args);  [/{tyse}.{tys}]          
        //     // $sql = "SELECT typeservice.name_tysbv,subservice.name
        //     // FROM subservice 
        //     // INNER JOIN typeservice
        //     // ON subservice.typeservice_id=typeservice.id  GROUP BY subservice.name";

        //     $sql = "SELECT typeservice.name_tysbv,subservice.name
        //     FROM typeservice 
        //     INNER JOIN subservice
        //     ON typeservice.id = subservice.typeservice_id GROUP BY subservice.name";

        //     // $sql = "SELECT subservice.name, typeservice.name FROM typeservice,subservice WHERE subservice.typeservice_id='$args[tyse]' AND typeservice.id='$args[tys]' ";
        //     // $sql = "SELECT * FROM typeservice,subservice
        //     // JOIN subservice ON subservice.typeservice_id='$args[tyse]' = typeservice.id='$args[tyse]' ";/* SQL**** ผ่าน*/

        //     // $sql = "SELECT * FROM typeservice,subservice WHERE id='$args[tyse]' AND typeservice_id='$args[sbse]' ";/* SQL**** ผ่าน*/
        //     $sts = $this->db->prepare($sql);
        //     $sts->execute();            
        //     $user = $sts->fetchAll();
        //     // rowCount
        //     return $this->response->withJson($user); 
        //  });

        //  $app->get('/ty_sbse/{tysb}',function(Request $request,Response $response,array $args)use($container) {
            

        //     $sql = "SELECT typeservice.name_tysbv,subservice.name
        //     FROM typeservice 
        //     ";

        //     $sts = $this->db->prepare($sql);
        //     $sts->execute();            
        //     $user = $sts->fetchAll();
        //     // rowCount
        //     return $this->response->withJson($user); 
        //  });


         

        //  $app->get('/im',function(Request $request,Response $response,array $args)use($container) {
        //     // $body = $this->request->getParsedBody(); 
        //     $sql = "SELECT * FROM image  ";   /* SQL**** ผ่าน*/
        //     $sts = $this->db->prepare($sql);
        //     $sts->execute();            
        //     $image = $sts->fetchAll();

        //    return $this->response->withJson($image);  });

        //  $app->get('/users/{us}.{ps}',function(Request $request,Response $response,array $args)use($container) {
        //     // $body = $this->request->getParsedBody(); 
        //     var_dump($args);
        //     // $sql = "SELECT * FROM user WHERE username='$args[us]' AND password='$args[ps]'    ";/* SQL**** ผ่าน*/
        //     // $sts = $this->db->prepare($sql);
        //     // $sts->execute();            
        //     // $user = $sts->fetchAll();
        //     // // rowCount
        //     // return $this->response->withJson($user); 
        //  });
         // -------------------------เรียกข้อมูล---ตาม--ID-----------------------------------------------------------------

        //  $sql = "SELECT * FROM user WHERE username='$args[username]' OR password='$args[password]'    ";/* SQL**** ผ่าน*/
         $app->get('/use/login/{username}.{password}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM user WHERE username='$args[username]' OR password='$args[password]'    ";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $user = $sts->rowCount(); 
            return $this->response->withJson($user);  });

            // select data in user full

            
        // $app->post('/grin',function(Request $request,Response $response,array $args)use($container){
        //     $body = $this->request->getParsedBody(); 
        //     $sql = "INSERT INTO grade  (reviews, suggestion, status, Imgproblem, booking_id) 
        //     VALUES (:reviews,:suggestion,:status,:Imgproblem,:booking_id) "; /* SQL* */
        //     $sts = $this->db->prepare($sql);
        //     $sts->bindParam ("reviews",$body['reviews']);  
        //     $sts->bindParam ("suggestion",$body['suggestion']);  
        //     $sts->bindParam ("status",$body['status']);   
        //     $sts->bindParam ("Imgproblem",$body['Imgproblem']);  
        //     $sts->bindParam ("booking_id",$body['booking_id']);              /* DATA**** */

        //     $sts->execute();            
        //     $grade = $sts->fetchAll(); 

        //    return $this->response->withJson($grade); });
          //-------------------------------------FK------------------------------------------
        
        $app->get('/bilf/{userid_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM bill WHERE userid_id='$args[userid_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $bill = $sts->fetchAll(); 
            return $this->response->withJson($bill);  });
        $app->get('/bokf/{bill_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM booking WHERE bill_id='$args[bill_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $booking = $sts->fetchAll(); 
            return $this->response->withJson($booking);  });
        $app->get('/busf/{user_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM business WHERE user_id='$args[user_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $business = $sts->fetchAll(); 
            return $this->response->withJson($business);  });
            
//---------------------------------------------ข้อมูลรายระเอียดสถานที่-----------------------------------------------------------
            $app->get('/busmeat/{business_id}',function(Request $request,Response $response,array $args)use($container) {
                // $body = $this->request->getParsedBody(); 
                $sql = "SELECT business.id,  business.name0 as bus_name0, business.name1 as bus_name1, business.name2 as bus_name2, business.parking as bus_parking, business.pattern as bus_pattern, typeplaceother.name_typo as bus_typename, business.address as bus_address, business.location  as bus_location, business.detail as bus_detail ,districts.name_in_thai as bus_aumper , subdistricts.name_in_thai as bus_tambon
                FROM business 
                INNER JOIN typeplaceother ON typeplaceother.id = business.typebusines_id
                INNER JOIN districts ON districts.id = business.districts0_id
				INNER JOIN subdistricts ON subdistricts.code = business.districts_id
                WHERE  business.id='$args[business_id]'";/* SQL**** ผ่าน*/
                $sts = $this->db->prepare($sql);
                $sts->execute();            
                $business = $sts->fetchAll(); 
                return $this->response->withJson($business);  });

               
//---------------------------------------------การค้นหาข้องผู้ใช้ทั่วไป------------------------------------------------------------
        $app->get('/busts/{districts_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            // SELECT DISTINCT business.name0, business.detail, image.name as img, placeother.ofbusiness_id
            // FROM business 
            // INNER JOIN image ON business.id=image.business_id
            // INNER JOIN placeother ON business.id=placeother.ofbusiness_id     
            // SELECT DISTINCT business.name0, business.detail, image.name as img, business.id
            // FROM business 
            // INNER JOIN image ON business.id=image.business_id                     
            // WHERE pattern='ที่พัก' AND districts_id='560101'        
            
            $sql = " SELECT DISTINCT business.name0, business.detail, image.name as img, business.id
            FROM business 
            INNER JOIN image ON business.id=image.business_id                     
                      
            WHERE pattern='ที่พัก' AND districts_id='$args[districts_id]' AND image.room_id = '0' ";/* SQL**** ผ่าน*/

            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $business = $sts->fetchAll(); 
            return $this->response->withJson($business);  });
        $app->get('/bustv/{districts_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT DISTINCT business.name0, business.detail, image.name as img, placeother.ofbusiness_id
            FROM business 
            INNER JOIN image ON business.id=image.business_id
            INNER JOIN placeother ON business.id=placeother.ofbusiness_id
            WHERE pattern='ที่เที่ยว' AND districts_id='$args[districts_id]'";/* SQL**** ผ่าน*/

            // $sql = "SELECT * FROM business WHERE typebusines='ที่เที่ยว'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $business = $sts->fetchAll(); 
            return $this->response->withJson($business);  });
            //----ข้อมูลสถานที่ใกล้เคียง---อิงตาม----Id---สถานที่------
        $app->get('/scdetail/{business_id}',function(Request $request,Response $response,array $args)use($container) {           
            $sql = "SELECT placeother.id,
            typeplaceother.name_typo as sttv_typepot, placeother.name as sttv_potnamebus, placeother.length as sttv_lengthbus, business.name0 as sttv_shotbus 
            ,business.id as bus_id             
            FROM placeother
            INNER JOIN typeplaceother ON placeother.typeplaceother_id=typeplaceother.id
            INNER JOIN business ON placeother.business_id=business.id 
            WHERE ofbusiness_id='$args[business_id]'";
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $search = $sts->fetchAll();       
            return $this->response->withJson($search); 
         });
          // $body = $this->request->getParsedBody();
          // ข้อมูลย่อยสถานที่
          //----ข้อมูลสถานที่ใกล้เคียง---อิงตาม----Id---สถานที่------          
//---------------------------------------------การค้นหาข้องผู้ใช้ทั่วไป------------------------------------------------------------
//------------------------การค้นหาข้องผู้ใช่สมาชิก---------- room.amountroom, room.amountpeople, room.price, typeroom.name---------------------------
$app->get('/busmbts/{districts_id}',function(Request $request,Response $response,array $args)use($container) {
    // $body = $this->request->getParsedBody(); 
    $sql = "SELECT business.id, business.name0, business.name1, business.name2, business.parking, business.detail,
    business.address, business.location, business.pattern, typeplaceother.name_typo 
    FROM business INNER JOIN typeplaceother ON business.typebusines_id = typeplaceother.id 
    WHERE pattern='ที่พัก' AND districts_id='$args[districts_id]'";/* SQL**** ผ่าน*/

    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $business = $sts->fetchAll(); 
    return $this->response->withJson($business);  });

$app->get('/busmbtv/{districts_id}',function(Request $request,Response $response,array $args)use($container) {
    // $body = $this->request->getParsedBody(); 
    $sql = "SELECT business.id, business.name0, business.name1, business.name2, business.parking, business.detail,
    business.address, business.location, business.pattern, typeplaceother.name_typo 
    FROM business INNER JOIN typeplaceother ON business.typebusines_id = typeplaceother.id
    WHERE pattern='ที่เที่ยว' AND districts_id='$args[districts_id]'";/* SQL**** ผ่าน*/

    // $sql = "SELECT * FROM business WHERE typebusines='ที่เที่ยว'";/* SQL**** ผ่าน*/
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $business = $sts->fetchAll(); 
    return $this->response->withJson($business);  });

    $app->get('/busmbst_tv/{business_id}',function(Request $request,Response $response,array $args)use($container) {
        // $body = $this->request->getParsedBody(); 
        $sql = "SELECT  business.id as bus_id,  business.name0 as bus_name0, business.name1 as bus_name1, business.name2 as bus_name2, business.parking as bus_parking, 
        business.detail as bus_detail, business.address as bus_address, business.location  as bus_location, business.pattern  as bus_pattern, typeplaceother.name_typo as bus_typebusiness
        FROM business 
        INNER JOIN typeplaceother ON business.typebusines_id = typeplaceother.id
        WHERE  business.id='$args[business_id]'";/* SQL**** ผ่าน*/
    // INNER JOIN typeplaceother ON business.typebusines_id = typeplaceother.id
        // $sql = "SELECT * FROM business WHERE typebusines='ที่เที่ยว'";/* SQL**** ผ่าน*/
        $sts = $this->db->prepare($sql);
        $sts->execute();            
        $business = $sts->fetchAll(); 
        return $this->response->withJson($business);  });
         //--------------รุปภาพ--และ--คำบรรยายสถานที่-----------
         $app->get('/imgmbbus/{business_id}',function(Request $request,Response $response,array $args)use($container) {           
            $sql = "SELECT image.name,image.details FROM image
            WHERE business_id='$args[business_id]' ";
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $search = $sts->fetchAll();       
            return $this->response->withJson($search); 
         });
         //--------------รุปภาพ--และ--คำบรรยายสถานที่------------
         //--------------บริการ--ของสถานที่ที่มีให้------------------
         $app->get('/svtmbbus/{business_id}',function(Request $request,Response $response,array $args)use($container) {           
            $sql = " SELECT typeservice.name_tysbv, subservice.name FROM tags
            INNER JOIN subservice ON subservice.id = tags.service_id
            INNER JOIN typeservice ON typeservice.id = subservice.typeservice_id
            WHERE business_id='$args[business_id]'";
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $search = $sts->fetchAll();       
            return $this->response->withJson($search); 
         });        
         //--------------บริการ--ของสถานที่ที่มีให้------------------        
         //--------------ห้องพัก--และ--รายระเอียด----------------
         $app->get('/roommbbus/{business_id}',function(Request $request,Response $response,array $args)use($container) {           
            $sql = "SELECT typeroom.name, room.amountpeople, room.price
            FROM room
            INNER JOIN typeroom ON room.typeroom_id = typeroom.id
            WHERE busines_id='$args[business_id]'";
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $search = $sts->fetchAll();       
            return $this->response->withJson($search); 
         });
         //--------------ห้องพัก--และ--รายระเอียด----------------
//---------------------------------------------การค้นหาข้องผู้ใช่สมาชิก------------------------------------------------------------
// SELECT  
//     business.name0, business.name1, business.name2, business.parking, business.establish, business.address, business.pricel, business.pricem, business.priceh,
//     image.name as img, image.details as detailimg   
//     FROM business
//     INNER JOIN image ON business.id=image.business_id
//     INNER JOIN room ON business.id=room.busines_id     
//     INNER JOIN typeroom ON room.typeroom_id=typeroom.id
//---------------------------------หาข้อมุลเพิ่มบริการสถานที่---------------------------------------------
$app->get('/buspt',function(Request $request,Response $response,array $args)use($container) {           
    $sql = "SELECT DISTINCT business.pattern FROM business WHERE business.pattern != ''";
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $pattern = $sts->fetchAll();       
    return $this->response->withJson($pattern); 
 });
 $app->get('/busptn/{pattern}',function(Request $request,Response $response,array $args)use($container) {
    // $body = $this->request->getParsedBody(); 
    $sql = "SELECT  business.id, business.name0  FROM business WHERE pattern='$args[pattern]'";/* SQL**** ผ่าน*/
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $patternn = $sts->fetchAll(); 
    return $this->response->withJson($patternn);  });

 $app->get('/busallsev/{id}',function(Request $request,Response $response,array $args)use($container) {           
    $sql = "SELECT tags.id AS tagsid, business.id AS busid, business.name0, subservice.name, typeservice.name_tysbv FROM business
    INNER JOIN tags ON	business.id = tags.business_id
    INNER JOIN subservice ON tags.service_id = subservice.id
    INNER JOIN typeservice ON subservice.typeservice_id = typeservice.id
    WHERE tags.business_id = '$args[id]' ";
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $search = $sts->fetchAll();       
    return $this->response->withJson($search); 
 });
 $app->get('/busallsev',function(Request $request,Response $response,array $args)use($container) {           
    $sql = "SELECT tags.id AS tagsid, business.id AS busid, business.name0, subservice.name, typeservice.name_tysbv FROM business
    INNER JOIN tags ON	business.id = tags.business_id
    INNER JOIN subservice ON tags.service_id = subservice.id
    INNER JOIN typeservice ON subservice.typeservice_id = typeservice.id
    -- WHERE tags.business_id = '$args[id]'
    ";
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $search = $sts->fetchAll();       
    return $this->response->withJson($search); 
 });

//---------------------------------หาข้อมุลเพิ่มบริการสถานที่---------------------------------------------

//----------------------------ผู้สั่งจอง---คือ--ใคลสั่งจองเรา------------ผู้ส่ง----------------------------------
        $app->get('/bookingmeto',function(Request $request,Response $response,array $args)use($container) {           
            $sql = "SELECT booking.id, business.name0, typeplaceother.name_typo, booking.checkin, booking.checkout, booking.people, booking.message, booking.booking_status FROM business INNER JOIN booking ON business.id = booking.ofbusiness_id INNER JOIN typeplaceother ON business.typebusines_id = typeplaceother.id ORDER BY booking.checkin DESC   
            ";
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $search = $sts->fetchAll();       
            return $this->response->withJson($search); 
        });
//  -- WHERE booking.ofbusiness_id = '$args[id]'
//----------------------------ผู้สั่งจอง---คือ--ใคลสั่งจองเรา------------ผู้ส่ง----------------------------------
//----------------------------ผู้รับจอง--คือ--ใคลรับจองเรา---------------ผุ้รับ-------------------------------
        $app->get('/bookingtoyou',function(Request $request,Response $response,array $args)use($container) {           
            $sql = "SELECT booking.id, business.name0, typeplaceother.name_typo, booking.checkin, booking.checkout, booking.people, booking.message, booking.booking_status FROM business INNER JOIN booking ON business.id = booking.busines_id INNER JOIN typeplaceother ON business.typebusines_id = typeplaceother.id ORDER BY booking.checkin DESC";
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $search = $sts->fetchAll();       
            return $this->response->withJson($search); 
        });
//  -- WHERE booking.ofbusiness_id = '$args[id]' 
//-------------------------------------------------------------------------
//----------------------------ผู้รับจอง--คือ--ใคลรับจองเรา---------------ผุ้รับ-------------------------------
$app->get('/bookingdetail/{id}',function(Request $request,Response $response,array $args)use($container) {           
    $sql = "  SELECT booking.id, business.name0, booking.create_booking, booking.booking_status, booking.checkin, booking.checkout, typeplaceother.name_typo, booking.people, booking.car, booking.ctmname, booking.ctmphone, booking.ctmemail, booking.message
    FROM booking
    INNER JOIN business ON business.id = booking.busines_id
    INNER JOIN typeplaceother ON typeplaceother.id = business.typebusines_id
    WHERE booking.id='$args[id]'";    
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $search = $sts->fetchAll();       
    return $this->response->withJson($search); 
});
//  -- WHERE booking.ofbusiness_id = '$args[id]' 
//-------------------------------------------------------------------------
//---------------------------รูปภาพสถานที่ทั้งหมด-------------------------------
$app->get('/busimgall',function(Request $request,Response $response,array $args)use($container) {           
    $sql = "SELECT business.name0, typeplaceother.name_typo, image.details, image.name, image.id
    FROM business 
    INNER JOIN image ON business.id = image.business_id
    INNER JOIN typeplaceother ON business.typebusines_id = typeplaceother.id
    WHERE NOT image.room_id";
    
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $image = $sts->fetchAll();       
    return $this->response->withJson($image); 
});
//  -- WHERE booking.ofbusiness_id = '$args[id]' 
$app->get('/busimgall/{id}',function(Request $request,Response $response,array $args)use($container) {           
    $sql = "SELECT business.name0, typeplaceother.name_typo, image.details, image.name, image.id
    FROM business 
    INNER JOIN image ON business.id = image.business_id
    INNER JOIN typeplaceother ON business.typebusines_id = typeplaceother.id
    WHERE NOT image.room_id AND image.id = '$args[id]'";
    
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $imageid = $sts->fetchAll();       
    return $this->response->withJson($imageid); 
});
//-------------------------------------------------------------------------
//---------------------------รูปภาพห้องทั้งหมด-------------------------------
$app->get('/busroomimgall',function(Request $request,Response $response,array $args)use($container) {           
    $sql = "SELECT business.name0, typeroom.name AS typrname, image.name AS roomimgurl, image.details ,image.id 
    FROM image 
    INNER JOIN business ON business.id = image.business_id INNER JOIN room ON room.id = image.room_id INNER JOIN typeroom ON typeroom.id = room.typeroom_id";
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $image = $sts->fetchAll();       
    return $this->response->withJson($image); 
});
$app->get('/busroomimgall/{id}',function(Request $request,Response $response,array $args)use($container) {           
    $sql = "SELECT business.name0, typeroom.name AS typrname, image.name AS roomimgurl, image.details ,image.id 
    FROM image 
    INNER JOIN business ON business.id = image.business_id INNER JOIN room ON room.id = image.room_id INNER JOIN typeroom ON typeroom.id = room.typeroom_id
    WHERE image.id = '$args[id]'";
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $imagerid = $sts->fetchAll();       
    return $this->response->withJson($imagerid); 
});

$app->get('/busupimg/{id}',function(Request $request,Response $response,array $args)use($container) {           
    $sql = "SELECT business.name0 AS img_name0 , image.name AS img_name, image.details AS img_details, image.id, image.business_id AS img_bus
    FROM  image
    INNER JOIN business ON image.business_id = business.id
    WHERE image.business_id = '$args[id]' 
    LIMIT 1;";
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $imagerid = $sts->fetchAll();       
    return $this->response->withJson($imagerid); 
});

// $app->patch('/busupimg/{id}',function(Request $request,Response $response,array $args)use($container) {
//     $body = $this->request->getParsedBody();     
//     $sql = "SELECT business.name0, image.name, image.details, image.id
//     FROM  image
//     INNER JOIN business ON image.business_id = business.id
//     WHERE image.business_id = '$args[id]' 
//     LIMIT 1;"; /* SQL**** */
//     $sts = $this->db->prepare($sql);
//     // $sts->bindParam ("id",$body['id']);  id=:id, ,user_id=:user_id,room_id=:room_id,business_id=:business_id
//     $sts->bindParam ("name",$body['name']);  
//     $sts->bindParam ("details",$body['details']);  
//     // $sts->bindParam ("user_id",$body['user_id']);  
//     $sts->bindParam ("room_id",$body['room_id']);
//     // $sts->bindParam ("business_id",$body['business_id']);   /* DATA**** */
//     $sts->execute(); 
//    return $this->response->withJson($sts); });
//-------------------------แก่ไขข้อมูลรูปภาพ--------------------------
$app->patch('/busupimgall/{id}',function(Request $request,Response $response,array $args)use($container) {
    $body = $this->request->getParsedBody(); 
    
    $sql = "UPDATE image SET name=:name, details=:details WHERE id='$args[id]'"; /* SQL**** */
    $sts = $this->db->prepare($sql);
    // $sts->bindParam ("id",$body['id']);  id=:id, ,user_id=:user_id,room_id=:room_id,business_id=:business_id
    $sts->bindParam ("name",$body['name']);  
    $sts->bindParam ("details",$body['details']);  
    // $sts->bindParam ("user_id",$body['user_id']);  
    // $sts->bindParam ("room_id",$body['room_id']);
    // $sts->bindParam ("business_id",$body['business_id']);   /* DATA**** */
    $sts->execute(); 
   return $this->response->withJson($sts); });   

   $app->patch('/busupimgroom/{id}',function(Request $request,Response $response,array $args)use($container) {
    $body = $this->request->getParsedBody();     
    $sql = "UPDATE image SET name=:name, details=:details, room_id=:room_id WHERE id='$args[id]'"; /* SQL**** */
    $sts = $this->db->prepare($sql);
    // $sts->bindParam ("id",$body['id']);  id=:id, ,user_id=:user_id,room_id=:room_id,business_id=:business_id
    $sts->bindParam ("name",$body['name']);  
    $sts->bindParam ("details",$body['details']);  
    // $sts->bindParam ("user_id",$body['user_id']);  
    $sts->bindParam ("room_id",$body['room_id']);
    // $sts->bindParam ("business_id",$body['business_id']);   /* DATA**** */
    $sts->execute(); 
   return $this->response->withJson($sts); });

//    $sts->bindParam ("name",$body['name']);  
//    $sts->bindParam ("details",$body['details']);  
//    // $sts->bindParam ("user_id",$body['user_id']);  
//    // $sts->bindParam ("room_id",$body['room_id']);
//    // $sts->bindParam ("business_id",$body['business_id']);   /* DATA**** */
//-------------------แสดงข้อมูลห้องพัก--ตามธุรกิจ---------------------------
$app->get('/rodetai',function(Request $request,Response $response,array $args)use($container) {
    // $body = $this->request->getParsedBody(); 
    $sql = "SELECT  room.id, business.name0, typeroom.name, room.amountpeople, room.price
    FROM business
    INNER JOIN room ON room.busines_id = business.id
    INNER JOIN typeroom ON typeroom.id = room.typeroom_id";/* SQL**** ผ่าน*/
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $room = $sts->fetchAll(); 
    return $this->response->withJson($room);  });
 
//-------------------------------------------------------------------------
//-----------------ข้อมุล---สถานที่พัก--สำหรับเพิ่มห้อง-----------
$app->get('/busstadro',function(Request $request,Response $response,array $args)use($container) {
    // $body = $this->request->getParsedBody(); 
    $sql = " SELECT business.id, business.name0 FROM business 
    WHERE business.pattern = 'ที่พัก' ";/* SQL**** ผ่าน*/
    // WHERE business.user_id = '106' 
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $business = $sts->fetchAll();  
    return $this->response->withJson($business);  });
//-----------------ข้อมุล---สถานที่พัก--สำหรับเพิ่มห้อง-----------
//-----------------ข้อมุล---สถานที่--สำหรับเพิ่มที่ใกล้เคียง-----------
$app->get('/pon/{districts_id}.{business_id}',function(Request $request,Response $response,array $args)use($container) {
    // $body = $this->request->getParsedBody(); 
    $sql = " SELECT business.id AS addphotbus_ID , business.name0 AS addphotbus_name ,typeplaceother.id AS addphotbus_typeID,
    typeplaceother.name_typo  AS addphotbus_typename
    FROM business 
    INNER JOIN typeplaceother ON typeplaceother.id = business.typebusines_id 
    WHERE business.districts_id = '$args[districts_id]' AND business.id != '$args[business_id]' ";/* SQL**** ผ่าน*/    
    $sts = $this->db->prepare($sql);
    $sts->execute();            
    $business = $sts->fetchAll();  
    return $this->response->withJson($business);  });
//-----------------ข้อมุล---สถานที่--สำหรับเพิ่มที่ใกล้เคียง-----------
//-----------------เพิ่มสถานที่ไกล้เคียง------------
$app->post('/poinbus',function(Request $request,Response $response,array $args)use($container){
    $body = $this->request->getParsedBody(); 
    $sql = "INSERT INTO placeother  (length,business_id,ofbusiness_id) VALUES (:length,:business_id,:ofbusiness_id) "; /* SQL**** */
//     INSERT INTO placeother ( length, typeplaceother_id, business_id, ofbusiness_id) 
// VALUES ( '1', '9', '2', '2');
    $sts = $this->db->prepare($sql);  
    $sts->bindParam ("length",$body['length']);  
    $sts->bindParam ("business_id",$body['business_id']);  
    $sts->bindParam ("ofbusiness_id",$body['ofbusiness_id']);  /* DATA**** */
    $sts->execute(); 
   return $this->response->withJson($sts); });
//-----------------เพิ่มสถานที่ไกล้เคียง------------
// $app->post('/grin',function(Request $request,Response $response,array $args)use($container){
//     $body = $this->request->getParsedBody(); 
//     $sql = "INSERT INTO grade (name,reviews,suggestion,status,imgproblem,booking_id) 
//     VALUES (:name,:reviews,:suggestion,:status,:imgproblem,:booking_id) "; /* SQL* */
//     $sts = $this->db->prepare($sql);
//     $sts->bindParam ("name",$body['name']);  
//     $sts->bindParam ("reviews",$body['reviews']); 
//     $sts->bindParam ("suggestion",$body['suggestion']);  
//     $sts->bindParam ("status",$body['status']);   
//     $sts->bindParam ("imgproblem",$body['imgproblem']);  
//     $sts->bindParam ("booking_id",$body['booking_id']);              /* DATA**** */
//     $sts->execute();            
//    return $this->response->withJson($sts); });

        $app->get('/grf/{booking_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM grade WHERE booking_id='$args[booking_id]'";/* SQL**** ยังไม่ได้ต่อFK ***ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $grade = $sts->fetchAll(); 
            return $this->response->withJson($grade);  });
        $app->get('/imf/{business_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM image WHERE business_id='$args[business_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $image = $sts->fetchAll(); 
            return $this->response->withJson($image);  });
        $app->get('/mesf/{booking_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM message WHERE booking_id='$args[booking_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $message = $sts->fetchAll(); 
            return $this->response->withJson($message);  });
        $app->get('/pof/{typeplaceother_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM placeother WHERE typeplaceother_id='$args[typeplaceother_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $placeother = $sts->fetchAll(); 
            return $this->response->withJson($placeother);  });
        $app->get('/ptf/{typetransport_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM publictransport WHERE typetransport_id='$args[typetransport_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $publictransport = $sts->fetchAll(); 
            return $this->response->withJson($publictransport);  });
        $app->get('/rof/{busines_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM room WHERE busines_id='$args[busines_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $room = $sts->fetchAll(); 
            return $this->response->withJson($room);  });        
        $app->get('/rof1/{typeroom_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM room WHERE typeroom_id='$args[typeroom_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $room = $sts->fetchAll(); 
            return $this->response->withJson($room);  });
        $app->get('/svtf/{busines_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM servicetime WHERE busines_id='$args[busines_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $servicetime = $sts->fetchAll(); 
            return $this->response->withJson($servicetime);  });
        $app->get('/sbsf/{typeservice_id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM subservice WHERE typeservice_id='$args[typeservice_id]'";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $subservice = $sts->fetchAll(); 
            return $this->response->withJson($subservice);  });
            //-------------------------------------FK------------------------------------------

        $app->get('/bus',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM business  ";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $business = $sts->fetchAll(); 
                        
           return $this->response->withJson($business);  });

        $app->get('/gr',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM grade  ";/* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $grade = $sts->fetchAll(); 
            
            
           return $this->response->withJson($grade);  });

        $app->get('/im',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM image  ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $image = $sts->fetchAll();

           return $this->response->withJson($image);  });
        
        $app->get('/po',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM placeother  ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $placeother = $sts->fetchAll();

           return $this->response->withJson($placeother);  });

        $app->get('/pt',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM publictransport ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $publictransport = $sts->fetchAll();

           return $this->response->withJson($publictransport);  });

        $app->get('/ro',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM room ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $room = $sts->fetchAll();

           return $this->response->withJson($room);  });

        $app->get('/svt',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM servicetime ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $servicetime = $sts->fetchAll();

           return $this->response->withJson($servicetime);  });

        $app->get('/sbs',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM subservice ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $subservice = $sts->fetchAll();

           return $this->response->withJson($subservice);  });

        $app->get('/typo',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM typeplaceother  ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $typeplaceother = $sts->fetchAll();

           return $this->response->withJson($typeplaceother);  });

        $app->get('/tyr',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM typeroom  ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $typeroom = $sts->fetchAll();

           return $this->response->withJson($typeroom);  });

        
        $app->get('/tys',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM typeservice ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $typeservice = $sts->fetchAll();

           return $this->response->withJson($typeservice);  });

        $app->get('/tyt',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM typetransport ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $typetransport = $sts->fetchAll();

           return $this->response->withJson($typetransport);  });

        $app->get('/use',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM user ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $user = $sts->fetchAll();
           return $this->response->withJson($user);  });

         



        $app->post('/grin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO grade (name,reviews,suggestion,status,imgproblem,booking_id) 
            VALUES (:name,:reviews,:suggestion,:status,:imgproblem,:booking_id) "; /* SQL* */
            $sts = $this->db->prepare($sql);
            $sts->bindParam ("name",$body['name']);  
            $sts->bindParam ("reviews",$body['reviews']); 
            $sts->bindParam ("suggestion",$body['suggestion']);  
            $sts->bindParam ("status",$body['status']);   
            $sts->bindParam ("imgproblem",$body['imgproblem']);  
            $sts->bindParam ("booking_id",$body['booking_id']);              /* DATA**** */
            $sts->execute();            
           return $this->response->withJson($sts); });

        //    INSERT INTO `grade` (`id`, `name`, `reviews`, `suggestion`, `status`, `Imgproblem`, `booking_id`) VALUES (NULL, '', '', '', '', '', '')

        //    $app->post('/usein',function(Request $request,Response $response,array $args)use($container){
        //     $body = $this->request->getParsedBody(); 
        //     $sql = "INSERT INTO user (fname,lname,city,district,zipcode,address,Idcrad,Imgprofile,pnumbar,mnumbar,create_user,update_user,username,password,pincode,email,class,status) 
        //     VALUES (:fname,:lname,:city,:district,:zipcode,:address,:Idcrad,:Imgprofile,:pnumbar,:mnumbar,:create_user,:update_user,:username,:password,:pincode,:email,:class,:status)"; /* SQL**** */
        //     $sts = $this->db->prepare($sql);
        //     $sts->bindParam("fname",$body['fname']);
        //     $sts->bindParam("lname",$body['lname']);              $sts->bindParam("city",$body['city']);
        //     $sts->bindParam("district",$body['district']);        $sts->bindParam("zipcode",$body['zipcode']);
        //     $sts->bindParam("address",$body['address']);          $sts->bindParam("Idcrad",$body['Idcrad']);
        //     $sts->bindParam("Imgprofile",$body['Imgprofile']);                   
        //     $sts->bindParam("pnumbar",$body['pnumbar']);
        //     $sts->bindParam("mnumbar",$body['mnumbar']);          
        //     $sts->bindParam("create_user",$body['create_user']);
        //     $sts->bindParam("update_user",$body['update_user']);  
        //     $sts->bindParam("username",$body['username']);
        //     $sts->bindParam("password",$body['password']);        $sts->bindParam("pincode",$body['pincode']);
        //     $sts->bindParam("email",$body['email']);              
        //     $sts->bindParam("class",$body['class']);
        //     $sts->bindParam("status",$body['status']); /* DATA**** */
        //     $sts->execute(); 
        //    return $this->response->withJson($sts); });

        // INSERT INTO `tags`(`id`, `business_id`, `typeservice_id`, `service_id`) VALUES ([value-1],[value-2],[value-3],[value-4])

        $app->post('/addsvtbus',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO tags (business_id,typeservice_id,service_id) 
            VALUES (:business_id,:typeservice_id,:service_id)"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            $sts->bindParam("business_id",$body['business_id']);
            $sts->bindParam("typeservice_id",$body['typeservice_id']);             
            $sts->bindParam("service_id",$body['service_id']);    /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });
           

        $app->patch('/use/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE user SET  fname=:fname,           lname=:lname,               city=:city,                 district=:district,
            zipcode=:zipcode,       address=:address,           Idcrad=:Idcrad,            
            pnumbar=:pnumbar,       create_user=:create_user,   update_user=:update_user,   mnumbar=:mnumbar,  
            username=:username,     password=:password,         pincode=:pincode,           email=:email,
            class=:class,           status=:status     WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            $sts->bindParam("fname",$body['fname']);
            $sts->bindParam("lname",$body['lname']);              $sts->bindParam("city",$body['city']);
            $sts->bindParam("district",$body['district']);        $sts->bindParam("zipcode",$body['zipcode']);
            $sts->bindParam("address",$body['address']);          $sts->bindParam("Idcrad",$body['Idcrad']);
            $sts->bindParam("Imgprofile",$body['Imgprofile']);                   
            $sts->bindParam("pnumbar",$body['pnumbar']);
            $sts->bindParam("mnumbar",$body['mnumbar']);          
            $sts->bindParam("create_user",$body['create_user']);
            $sts->bindParam("update_user",$body['update_user']);  
            $sts->bindParam("username",$body['username']);
            $sts->bindParam("password",$body['password']);        $sts->bindParam("pincode",$body['pincode']);
            $sts->bindParam("email",$body['email']);              
            $sts->bindParam("class",$body['class']);
            $sts->bindParam("status",$body['status']);  /* DATA**** */
            
            $sts->execute();            
            $user = $sts->fetchAll(); 

           return $this->response->withJson($user); });

           $app->get('/mbuse/{id}',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM user WHERE id='$args[id]'";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $user = $sts->fetchAll();
           return $this->response->withJson($user);  });

        //    $app->get('/svtf/{busines_id}',function(Request $request,Response $response,array $args)use($container) {
        //     // $body = $this->request->getParsedBody(); 
        //     $sql = "SELECT * FROM servicetime WHERE busines_id='$args[busines_id]'";/* SQL**** ผ่าน*/
        //     $sts = $this->db->prepare($sql);
        //     $sts->execute();            
        //     $servicetime = $sts->fetchAll(); 
        //     return $this->response->withJson($servicetime);  });



        });
        //------------------------------------------------------------------------------------------------------
    $app->group('/so',function()use($app){
            $container = $app->getContainer();    
            
        $app->get('/bil',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM bill";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $bill = $sts->fetchAll();

           return $this->response->withJson($bill);  });                
        
        $app->get('/bok',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM booking "; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $booking = $sts->fetchAll();

           return $this->response->withJson($booking);  });

        $app->get('/mes',function(Request $request,Response $response,array $args)use($container) {
            // $body = $this->request->getParsedBody(); 
            $sql = "SELECT * FROM business  ";   /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
            $business = $sts->fetchAll();  /* DATA**** */

           return $this->response->withJson($business);  });
           


        $app->post('/bilin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO bill  (create_bil,update_bill,userid_id) VALUES (:create_bil,:update_bill,:userid_id) "; /* SQL**** */
            $sts = $this->db->prepare($sql);
            $sts->bindParam("name",$body['name']);           
            $sts->bindParam("create_bil",$body['create_bil']);
            $sts->bindParam("update_bill",$body['update_bill']);
            $sts->bindParam("userid_id",$body['userid_id']);      /* DATA**** */
            
            $sts->execute();            
            $bill = $sts->fetchAll(); 

           return $this->response->withJson($bill); });

        $app->post('/bokin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO booking  (checkin,checkout,people,car,ctmname,ctmphone,ctmemail,message,create_booking,update_booking,cancel_booking,booking_status, busines_id,ofbusines_id) 
            VALUES (:checkin,:checkout,:people,:car,:ctmname,:ctmphone,:ctmemail,:message,:create_booking,:update_booking,:cancel_booking, :booking_status,:busines_id,ofbusines_id) "; /* SQL**** */
            $sts = $this->db->prepare($sql);
            $sts->bindParam("checkin",$body['checkin']);  
            $sts->bindParam("checkout",$body['checkout']);  
            $sts->bindParam("people",$body['people']);  
            $sts->bindParam("car",$body['car']); 
            $sts->bindParam("ctmname",$body['ctmname']);  
            $sts->bindParam("ctmphone",$body['ctmphone']);  
            $sts->bindParam("ctmemail",$body['ctmemail']);  
            $sts->bindParam("message",$body['message']); 
            $sts->bindParam("create_booking",$body['create_booking']);  
            $sts->bindParam("update_booking",$body['update_booking']);  
            $sts->bindParam("cancel_booking",$body['cancel_booking']);  
            $sts->bindParam("booking_status",$body['booking_status']);  
            $sts->bindParam("busines_id",$body['busines_id']); 
            $sts->bindParam("ofbusines_id",$body['ofbusines_id']); /* DATA**** */
            
            $sts->execute(); 
           return $this->response->withJson($sts); });
           
           $app->post('/mebokin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO booking  (checkin,checkout,people,car,ctmname,ctmphone,ctmemail,message,busines_id,ofbusiness_id) 
            VALUES (:checkin,:checkout,:people,:car,:ctmname,:ctmphone,:ctmemail,:message,:busines_id,:ofbusiness_id) "; /* SQL**** */
            $sts = $this->db->prepare($sql);  
            $sts->bindParam ("checkin",$body['checkin']);  
            $sts->bindParam ("checkout",$body['checkout']);  
            $sts->bindParam ("people",$body['people']);  
            $sts->bindParam ("car",$body['car']);  
            $sts->bindParam ("ctmname",$body['ctmname']);  
            $sts->bindParam ("ctmphone",$body['ctmphone']);  
            $sts->bindParam ("ctmemail",$body['ctmemail']);  
            $sts->bindParam ("message",$body['message']);  
            $sts->bindParam ("busines_id",$body['busines_id']);  
            $sts->bindParam ("ofbusiness_id",$body['ofbusiness_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        //    INSERT INTO `booking` (`id`, `checkin`, `checkout`, `people`, `car`, `ctmname`, `ctmphone`, `ctmemail`, `create_booking`, `update_booking`, `message`, `booking_status`, `bill_id`, `busines_id`, `ofbusiness_id`) VALUES (NULL, '2020-11-03', '2020-11-03', '1', '2', '3', '4', '5', '', '', '6', 'รอการยืนยัน', '32', '2', '102')


           $app->post('/businmb',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO business  (name0,parking,detail,districts_id,pattern,user_id) 
            VALUES (:name0,:parking,:detail,:districts_id,:pattern,:user_id) "; /* SQL**** */
            $sts = $this->db->prepare($sql);  
            $sts->bindParam ("name0",$body['name0']);  
            $sts->bindParam ("parking",$body['parking']);  
            $sts->bindParam ("detail",$body['detail']);  
            $sts->bindParam ("districts_id",$body['districts_id']);  
            $sts->bindParam ("pattern",$body['pattern']);  
            $sts->bindParam ("user_id",$body['user_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->post('/busin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO business (name0,name1,name2,parking,detail,pnumber,mnumber,address,location,districts_id,typebusines_id,pattern, user_id) 
            VALUES (:name0,:name1,:name2,:parking,,:detail,:pnumber,:mnumber,:address,:location,:districts_id,:typebusines_id,pattern,:user_id) "; /* SQL**** */
            $sts = $this->db->prepare($sql);              
            $sts->bindParam("name0",$body['name0']);  
            $sts->bindParam("name1",$body['name1']);  
            $sts->bindParam("name2",$body['name2']);  
            $sts->bindParam("parking",$body['parking']);
            $sts->bindParam("detail",$body['detail']);  
            $sts->bindParam("pnumber",$body['pnumber']);  
            $sts->bindParam("mnumber",$body['mnumber']);  
            $sts->bindParam("address",$body['address']);  
            $sts->bindParam("location",$body['location']); 
            $sts->bindParam("districts_id",$body['districts_id']);            
            $sts->bindParam("typebusines_id",$body['typebusines_id']);  
            $sts->bindParam("pattern",$body['pattern']);                
            $sts->bindParam("user_id",$body['user_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->post('/imin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            
            $sql = "INSERT INTO image (name,details,room_id,business_id) VALUES (:name,:details,:room_id,:business_id) "; /* SQL**** */
            $sts = $this->db->prepare($sql); 
            $sts->bindParam ("name",$body['name']);  
            $sts->bindParam ("details",$body['details']);  
            // $sts->bindParam ("user_id",$body['user_id']);  
            $sts->bindParam ("room_id",$body['room_id']);  
            $sts->bindParam ("business_id",$body['business_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->post('/mesin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO message (text,booking_id) VALUES (:text,:booking_id)"; /* SQL**** */
            $sts = $this->db->prepare($sql);
            $sts->bindParam ("text",$body['text']);  
            $sts->bindParam ("booking_id",$body['booking_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->post('/poin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO placeother  (name,servicemodel,typeplaceother_id) VALUES (:name,:servicemodel,:typeplaceother_id) "; /* SQL**** */
            $sts = $this->db->prepare($sql);  
            $sts->bindParam ("name",$body['name']);  
            $sts->bindParam ("servicemodel",$body['servicemodel']);  
            $sts->bindParam ("typeplaceother_id",$body['typeplaceother_id ']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->post('/ptin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO publictransport  (name,distance,price,typetransport_id) VALUES (:name,:distance,:price,:typetransport_id) "; /* SQL**** */
            $sts = $this->db->prepare($sql); 
            $sts->bindParam ("name",$body['name']);  
            $sts->bindParam ("distance",$body['distance']);  
            $sts->bindParam ("price",$body['price']);  
            $sts->bindParam ("typetransport_id",$body['typetransport_id']);   /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->post('/roin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO room  (amountroom,amountpeople,price,statu,busines_id,typeroom_id) 
            VALUES (:amountroom,:amountpeople,:price,:statu,:busines_id,:typeroom_id) "; /* SQL**** */
            $sts = $this->db->prepare($sql);  
            $sts->bindParam ("amountroom",$body['amountroom']);  
            $sts->bindParam ("amountpeople",$body['amountpeople']);  
            $sts->bindParam ("price",$body['price']);  
            $sts->bindParam ("statu",$body['statu']);  
            $sts->bindParam ("busines_id",$body['busines_id']);  
            $sts->bindParam ("typeroom_id",$body['typeroom_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->post('/svtin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO servicetime  (nameshow,timeon,timeoff,amountperple,statu,busines_id) 
            VALUES (:nameshow,:timeon,:timeoff,:amountperple,:statu,:busines_id) "; /* SQL**** */
            $sts = $this->db->prepare($sql);  
            $sts->bindParam ("nameshow",$body['nameshow']);  
            $sts->bindParam ("timeon",$body['timeon']);  
            $sts->bindParam ("timeoff",$body['timeoff']);  
            $sts->bindParam ("amountperple",$body['amountperple']);  
            $sts->bindParam ("statu",$body['statu']);  
            $sts->bindParam ("busines_id",$body['busines_id']);        /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });



        $app->patch('/bil/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE bill SET create_bil=:create_bil,update_bill=:update_bill,userid_id=:userid_id WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            $sts->bindParam("name",$body['name']);
            $sts->bindParam("id",$body['id']);
            $sts->bindParam("create_bil",$body['create_bil']);
            $sts->bindParam("update_bill",$body['update_bill']);
            $sts->bindParam("userid_id",$body['userid_id']);      /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->patch('/bok/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE booking SET checkin=:checkin,checkout=:checkout,people=:people,car=:car,create_booking=:create_booking,update_booking=:update_booking,cancel_booking=:cancel_booking,booking_status=:booking_status,bill_id=:bill_id WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            $sts->bindParam("id",$body['id']);  
            $sts->bindParam("checkin",$body['checkin']);  
            $sts->bindParam("checkout",$body['checkout']);  
            $sts->bindParam("people",$body['people']);  
            $sts->bindParam("car",$body['car']);  
            $sts->bindParam("create_booking",$body['create_booking']);  
            $sts->bindParam("update_booking",$body['update_booking']);  
            $sts->bindParam("cancel_booking",$body['cancel_booking']);  
            $sts->bindParam("booking_status",$body['booking_status']);  
            $sts->bindParam("bill_id",$body['bill_id']);                /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->patch('/bus/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE business SET name0=:name0,name1=:name1,name2=:name2,parking=:parking,establish=:establish,detail=:detail,pnumber=:pnumber,mnumber=:mnumber,address=:address,typebusines=:typebusines,statu=:statu,user_id=:user_id  WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            // $sts->bindParam("id",$body['id']);  
            $sts->bindParam("name0",$body['name0']);  
            $sts->bindParam("name1",$body['name1']);  
            $sts->bindParam("name2",$body['name2']);  
            $sts->bindParam("parking",$body['parking']);  
            $sts->bindParam("establish",$body['establish']);  
            $sts->bindParam("detail",$body['detail']);  
            $sts->bindParam("pnumber",$body['pnumber']);  
            $sts->bindParam("mnumber",$body['mnumber']);  
            $sts->bindParam("address",$body['address']);  
            $sts->bindParam("typebusines",$body['typebusines']);  
            $sts->bindParam("statu",$body['statu']);  
            $sts->bindParam("user_id",$body['user_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->patch('/gr/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE grade SET reviews=:reviews,suggestion=:suggestion,status=:status,Imgproblem=:Imgproblem,booking_id=:booking_id  WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            
            $sts->bindParam ("reviews",$body['reviews']);  
            $sts->bindParam ("suggestion",$body['suggestion']);  
            $sts->bindParam ("status",$body['status']);   
            $sts->bindParam ("Imgproblem",$body['Imgproblem']);  
            $sts->bindParam ("booking_id",$body['booking_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->patch('/im/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE image SET name=:name,details=:details,user_id=:user_id,business_id=:business_id WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

         
            $sts->bindParam ("name",$body['name']);  
            $sts->bindParam ("details",$body['details']);  
            $sts->bindParam ("user_id",$body['user_id']);  
            $sts->bindParam ("business_id",$body['business_id']);   /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->patch('/mes/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE message SET text=:text,booking_id=:booking_id WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

           
            $sts->bindParam ("text",$body['text']);  
            $sts->bindParam ("booking_id",$body['booking_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->patch('/po/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE placeother SET name=:name,servicemodel=:servicemodel,typeplaceother_id=:typeplaceother_id WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

         
            $sts->bindParam ("name",$body['name']);  
            $sts->bindParam ("servicemodel",$body['servicemodel']);  
            $sts->bindParam ("typeplaceother_id",$body['typeplaceother_id ']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->patch('/pt/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE publictransport SET name=:name,distance=:distance,price=:price,typetransport_id=:typetransport_id  WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);
              
            $sts->bindParam ("name",$body['name']);  
            $sts->bindParam ("distance",$body['distance']);  
            $sts->bindParam ("price",$body['price']);  
            $sts->bindParam ("typetransport_id",$body['typetransport_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->patch('/ro/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE room SET amountroom=:amountroom,amountpeople=:amountpeople,price=:price,statu=:statu,busines_id=:busines_id,typeroom_id=:typeroom_id  WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

             
            $sts->bindParam ("amountroom",$body['amountroom']);  
            $sts->bindParam ("amountpeople",$body['amountpeople']);  
            $sts->bindParam ("price",$body['price']);  
            $sts->bindParam ("statu",$body['statu']);  
            $sts->bindParam ("busines_id",$body['busines_id']);  
            $sts->bindParam ("typeroom_id",$body['typeroom_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->patch('/svt/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE servicetime SET id=:id,nameshow=:nameshow,timeon=:timeon,timeoff=:timeoff,amountperple=:amountperple,statu=:statu,busines_id=:busines_id   WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            
            $sts->bindParam ("nameshow",$body['nameshow']);  
            $sts->bindParam ("timeon",$body['timeon']);  
            $sts->bindParam ("timeoff",$body['timeoff']);  
            $sts->bindParam ("amountperple",$body['amountperple']);  
            $sts->bindParam ("statu",$body['statu']);  
            $sts->bindParam ("busines_id",$body['busines_id']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });


        });
        //------------------------------------------------------------------------------------------------------
    $app->group('/sp',function()use($app){
            $container = $app->getContainer(); 
        $app->post('/sbsin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO subservice (name,typeservice_id) VALUES (:name,:typeservice_id) "; /* SQL**** */
            $sts = $this->db->prepare($sql);
             
            $sts->bindParam ("name",$body['name']);  
            $sts->bindParam ("typeservice_id",$body['typeservice_id']); /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->post('/typoin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO typeplaceother (name) VALUES (:name) "; /* SQL**** */
            $sts = $this->db->prepare($sql);           
            $sts->bindParam ("name",$body['name']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->post('/tyrin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO typeroom (name) VALUES (:name) "; /* SQL**** */
            $sts = $this->db->prepare($sql);
            $sts->bindParam ("name",$body['name']); /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });
           
        $app->post('/tysin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO typeservice (name) VALUES (:name) "; /* SQL**** */
            $sts = $this->db->prepare($sql); 
            $sts->bindParam ("name",$body['name']); /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->post('/tytin',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO typetransport (name) VALUES (:name)"; /* SQL**** */
            $sts = $this->db->prepare($sql); 
            $sts->bindParam ("name",$body['name']);   /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

        $app->post('/usein',function(Request $request,Response $response,array $args)use($container){
            $body = $this->request->getParsedBody(); 
            $sql = "INSERT INTO user (fname,lname,city,district,zipcode,address,Idcrad,Imgprofile,pnumbar,mnumbar,create_user,update_user,username,password,pincode,email,class,status) 
            VALUES (:fname,:lname,:city,:district,:zipcode,:address,:Idcrad,:Imgprofile,:pnumbar,:mnumbar,:create_user,:update_user,:username,:password,:pincode,:email,:class,:status)"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            $sts->bindParam("fname",$body['fname']);
            $sts->bindParam("lname",$body['lname']);              $sts->bindParam("city",$body['city']);
            $sts->bindParam("district",$body['district']);        $sts->bindParam("zipcode",$body['zipcode']);
            $sts->bindParam("address",$body['address']);          $sts->bindParam("Idcrad",$body['Idcrad']);
            $sts->bindParam("Imgprofile",$body['Imgprofile']);                   
            $sts->bindParam("pnumbar",$body['pnumbar']);
            $sts->bindParam("mnumbar",$body['mnumbar']);          
            $sts->bindParam("create_user",$body['create_user']);
            $sts->bindParam("update_user",$body['update_user']);  
            $sts->bindParam("username",$body['username']);
            $sts->bindParam("password",$body['password']);        $sts->bindParam("pincode",$body['pincode']);
            $sts->bindParam("email",$body['email']);              
            $sts->bindParam("class",$body['class']);
            $sts->bindParam("status",$body['status']); /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });
           


        $app->patch('/sbs/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE subservice SET name=:name,typeservice_id=:typeservice_id  WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            $sts->bindParam ("id",$body['id']);  
            $sts->bindParam ("name",$body['name']);  
            $sts->bindParam ("typeservice_id",$body['typeservice_id']);   /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->patch('/typo/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE typeplaceother SET name=:name  WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            $sts->bindParam ("id",$body['id']);  
            $sts->bindParam ("name",$body['name']);   /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->patch('/tyr/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE typeroom SET name=:name  WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            $sts->bindParam ("id",$body['id']);  
            $sts->bindParam ("name",$body['name']);   /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->patch('/tys/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE typeservice SET name=:name  WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            $sts->bindParam ("id",$body['id']);  
            $sts->bindParam ("name",$body['name']);  /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->patch('/tyt/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE typetransport SET name=:name  WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);

            $sts->bindParam ("id",$body['id']);  
            $sts->bindParam ("name",$body['name']);              /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->patch('/use/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql = "UPDATE user SET fname=:fname,               lname=:lname,               city=:city,                 district=:district,
            zipcode=:zipcode,       address=:address,           Idcrad=:Idcrad,            
            pnumbar=:pnumbar,       create_user=:create_user,   update_user=:update_user,   mnumbar=:mnumbar,  
            username=:username,     password=:password,         pincode=:pincode,           email=:email,
            class=:class,           status=:status  WHERE id='$args[id]'"; /* SQL**** */
            $sts = $this->db->prepare($sql);
                   
            $sts->bindParam("fname",$body['fname']);
            $sts->bindParam("lname",$body['lname']);              $sts->bindParam("city",$body['city']);
            $sts->bindParam("district",$body['district']);        $sts->bindParam("zipcode",$body['zipcode']);
            $sts->bindParam("address",$body['address']);          $sts->bindParam("Idcrad",$body['Idcrad']);
            $sts->bindParam("Imgprofile",$body['Imgprofile']);                   
            $sts->bindParam("pnumbar",$body['pnumbar']);
            $sts->bindParam("mnumbar",$body['mnumbar']);          
            $sts->bindParam("create_user",$body['create_user']);
            $sts->bindParam("update_user",$body['update_user']);  
            $sts->bindParam("username",$body['username']);
            $sts->bindParam("password",$body['password']);        $sts->bindParam("pincode",$body['pincode']);
            $sts->bindParam("email",$body['email']);              
            $sts->bindParam("class",$body['class']);
            $sts->bindParam("status",$body['status']); /* DATA**** */
            $sts->execute(); 
           return $this->response->withJson($sts); });

            

        $app->delete('/bil/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM bill WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/bok/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM booking WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/bus/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM business WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/gr/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM grade WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/im/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM image WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/mes/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM message WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/po/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM placeother WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/pt/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM publictransport WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/ro/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM room WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/svt/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM servicetime WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/sbs/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM subservice WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();            
           return $this->response->withJson($sts); });

           $app->delete('/typo/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM typeplaceother WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql); 
            $sts->execute();          
           return $this->response->withJson($sts); });

           $app->delete('/tyr/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM typeroom WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/tys/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM typeservice WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/tyt/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM typetransport WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute(); 
           return $this->response->withJson($sts); });

           $app->delete('/use/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM user WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();      
           return $this->response->withJson($sts); });

           $app->delete('/busmbsev/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM tags WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();      
           return $this->response->withJson($sts); });

           $app->delete('/busroommbsev/{id}',function(Request $request,Response $response,array $args)use($container) {
            $body = $this->request->getParsedBody(); 
            $sql="DELETE FROM room WHERE id='$args[id]'"; /* SQL**** ผ่าน*/
            $sts = $this->db->prepare($sql);
            $sts->execute();      
           return $this->response->withJson($sts); });

      
          
        });

};
